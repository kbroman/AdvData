final_rbm_data.xls            RBM immunoassay data
RBM_Tube_Number_Key.xls       contains the mouse/sample ID correspondence
                              for final_rbm_data.xls

CPL_Rosetta_Lipids_FINAL.xls  The trait measurements are in the last four columns

Complete F2 Liver TG Set.xls  Relevant are Sex, Body Weight, Total.Liver.Weight,
                              Glucose, Insulin, Plasma TG, ug TG/mg Protein

pheno_lipomics_bleeds.xls     we're interested in sex,
                              + weeks 4,6,8,10: weight, length, glucose, insulin, triglyceride
                              + last few columns with week 10 insulin, c-peptide, and glucose

necropsy_tracking_report.xls  we're interested in the organ weights
                              plus number of harvested pancreatic islets ("Approx. # harvested")
